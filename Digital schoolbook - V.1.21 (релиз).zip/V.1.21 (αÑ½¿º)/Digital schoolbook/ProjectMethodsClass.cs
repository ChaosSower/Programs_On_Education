﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using DataManipulator;
using DictionariesKeeper;

namespace Digital_schoolbook
{
    public class ProjectMethodsClass
    {
        // Получение ссылок //
        public DataManipulatorClass _CurrentData; // получение ссылки на переменную хранимых данных проекта
        public TreeView _ContentsBookmarkList; // получение ссылки на дерево закладок
        public RichTextBox _BookmarkDescriptionRichTextBox; // получение ссылки на текстовое поле главной формы описания закладки
        public TextBox _BookmarkTimeInfoTextBox; // получение ссылки на текстовое поле главной формы данных о создании / редактировании закладки
        public TextBox _BookmarkChapterInfoTextBox; // получение ссылки на текстовое поле главной формы данных о главе закладки
        public RichTextBox _BookmarkContentRichTextBox; // получение ссылки на текстовое поле главной формы содержания закладки
        public CheckBox _CreatorModeCheckBox; // получение ссылки на чек-бокс смены режима редактирования содержимого закладки главной формы

        // Методы //

        // Метод возвращения состояния чек-бокса смены режима редактирования содержимого закладки
        public void FlipCreatorModeCheckBox()
        {
            _CreatorModeCheckBox.Checked = !_CreatorModeCheckBox.Checked;
        }

        // Метод создания новой закладки
        public void CreateBookmark()
        {
            TreeNode NewBookmark;

            if (_ContentsBookmarkList.SelectedNode != null)
            {
                NewBookmark = _ContentsBookmarkList.SelectedNode.Nodes.Add("Новая закладка");
            }

            else
            {
                NewBookmark = _ContentsBookmarkList.Nodes.Add("Новая закладка");
            }

            _ContentsBookmarkList.SelectedNode = NewBookmark;
        }

        // Метод удаления выбранной закладки
        public void DeleteCurrentBookmark(TreeNode SelectedNode)
        {
            if (SelectedNode == null)
            {
                MessageBox.Show("Вы не выбрали закладку для удаления!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DialogResult RemoveBookmarkDialogResult = MessageBox.Show("Вы действительно хотите удалить выбранную закладку?", "Удаление закладки", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (RemoveBookmarkDialogResult == DialogResult.Yes)
            {
                DeleteEachChildNodeOfSelectedNode(SelectedNode);

                DictionariesKeeperClass.ContentsBookmarkDictionary.Remove(SelectedNode.Text);
                SelectedNode.Remove();

                _BookmarkDescriptionRichTextBox.Text = null;
                _BookmarkTimeInfoTextBox.Text = null;
                _BookmarkChapterInfoTextBox.Text = null;
                _BookmarkContentRichTextBox.Text = null;
            }
        }

        // Метод удаления всех дочерних ветвей выбранного узла путём перебора
        public void DeleteEachChildNodeOfSelectedNode(TreeNode ParentTreeNode)
        {
            foreach (TreeNode ChildNode in ParentTreeNode.Nodes)
            {
                DeleteCurrentChildNode(ChildNode);
            }
        }

        // Метод удаления дочерней ветви [?]
        public void DeleteCurrentChildNode(TreeNode ParentTreeNode)
        {
            if (ParentTreeNode != null)
            {
                Queue<TreeNode> DeleteQueue = new();
                DeleteQueue.Enqueue(ParentTreeNode);

                while (DeleteQueue.Count > 0)
                {
                    ParentTreeNode = DeleteQueue.Dequeue();

                    DictionariesKeeperClass.ContentsBookmarkDictionary.Remove(ParentTreeNode.Text);

                    foreach (TreeNode ChildNode in ParentTreeNode.Nodes)
                    {
                        DeleteQueue.Enqueue(ChildNode);
                    }
                }
            }
        }

        // Метод получения версии веб-браузера с компьютера [?]
        public int GetWebBrowserVersion()
        {
            string KeyPath = @"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Internet Explorer";

            string[] BasicValuesString = new[]
            {
                "svcVersion",
                "svcUpdateVersion",
                "Version",
                "W2kVersion"
            };

            int MaximalBrowserLevel = 0;

            for (int i = 0; i < BasicValuesString.Length; ++i)
            {
                object ObjectValue = Microsoft.Win32.Registry.GetValue(KeyPath, BasicValuesString[i], "0");
                string StringValue = Convert.ToString(ObjectValue);

                if (StringValue != null)
                {
                    int IteratorPosition = StringValue.IndexOf('.');

                    if (IteratorPosition > 0)
                    {
                        StringValue = StringValue.Substring(0, IteratorPosition);
                    }

                    if (int.TryParse(StringValue, out int Result))
                    {
                        MaximalBrowserLevel = Math.Max(MaximalBrowserLevel, Result);
                    }
                }
            }

            return MaximalBrowserLevel;
        }

        // Метод сохранения версии браузера в реестр [?]
        public void WriteCompatibilityLevel(string RootPath, string AppName, int Level)
        {
            try
            {
                Microsoft.Win32.Registry.SetValue(RootPath + @"\Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION", AppName, Level);
            }

            catch (UnauthorizedAccessException)
            {
                //MessageBox.Show("Отказано в доступе к реестру");
            }
        }

        // Метод обновления версии веб-браузера [?]
        public void SetWebBrowserCompatibilityLevel()
        {
            string AppName = Path.GetFileNameWithoutExtension(Application.ExecutablePath);
            int Level = 1000 * GetWebBrowserVersion();
            bool FixVShost = File.Exists(Path.ChangeExtension(Application.ExecutablePath, ".vshost.exe"));

            WriteCompatibilityLevel("HKEY_LOCAL_MACHINE", AppName + ".exe", Level);

            if (FixVShost)
            {
                WriteCompatibilityLevel("HKEY_LOCAL_MACHINE", AppName + ".vshost.exe", Level);
            }

            WriteCompatibilityLevel("HKEY_CURRENT_USER", AppName + ".exe", Level);

            if (FixVShost)
            {
                WriteCompatibilityLevel("HKEY_CURRENT_USER", AppName + ".vshost.exe", Level);
            }
        }

        // Метод разбития словаря названий закладок на составные компоненты и дальнейшее их сохранение в файл
        public void TreeViewDividerAndSaver()
        {
            TreeViewToDictionaryConverter(_ContentsBookmarkList);

            int[] NodeKeys = DictionariesKeeperClass.ContentsBookmarkListTreeView.Keys.Select(x => x.Item1).ToArray();
            int[] NodeParentKeys = DictionariesKeeperClass.ContentsBookmarkListTreeView.Keys.Select(x => x.Item2).ToArray();
            ICollection<string> Values = DictionariesKeeperClass.ContentsBookmarkListTreeView.Values;

            _CurrentData.TreeViewNodeKey = new int[NodeKeys.Length];
            _CurrentData.TreeViewParentKey = new int[NodeParentKeys.Length];
            _CurrentData.TreeViewNodeText = new string[Values.Count];

            int i = 0;
            int j = 0;
            int k = 0;

            foreach (int Key in NodeKeys)
            {
                _CurrentData.TreeViewNodeKey[i] = Key;
                i++;
            }

            foreach (int Key in NodeParentKeys)
            {
                _CurrentData.TreeViewParentKey[j] = Key;
                j++;
            }

            foreach (string Value in Values)
            {
                _CurrentData.TreeViewNodeText[k] = Value;
                k++;
            }
        }

        // Метод конвертации названий закладок в словарь
        public void TreeViewToDictionaryConverter(TreeView CurrentTreeView)
        {
            ConvertEachNodeToDictionary(CurrentTreeView);
            DictionariesKeeperClass.ContentsBookmarkListTreeView.OrderBy(x => x.Key.Item1); // сортирует ключи изменённого словаря в порядке возрастания
        }

        private int TreeNodeIndex = 0;

        // Метод добавления всех дочерних ветвей в словарь путём перебора
        public void ConvertEachNodeToDictionary(TreeView TreeView)
        {
            foreach (TreeNode TreeNode in TreeView.Nodes)
            {
                AddCurrentNodeToDictionary(TreeNode, TreeNodeIndex);
            }
        }

        // Метод добавления дочерней ветви в словарь [?]
        public void AddCurrentNodeToDictionary(TreeNode CurrentTreeNode, int CurrentTreeNodeIndex)
        {
            if (CurrentTreeNode != null)
            {
                int ParentIndex; // индекс родителя текущей ветви
                Queue<TreeNode> CreateCopyQueue = new();
                CreateCopyQueue.Enqueue(CurrentTreeNode);

                while (CreateCopyQueue.Count > 0)
                {
                    CurrentTreeNode = CreateCopyQueue.Dequeue();

                    if (CurrentTreeNode.Parent == null)
                    {
                        ParentIndex = -1;
                    }

                    else
                    {
                        ParentIndex = DictionariesKeeperClass.ContentsBookmarkListTreeView.FirstOrDefault(x => x.Value == CurrentTreeNode.Parent.Text).Key.Item1;
                    }

                    DictionariesKeeperClass.ContentsBookmarkListTreeView.Add(Tuple.Create(CurrentTreeNodeIndex, ParentIndex), CurrentTreeNode.Text);
                    CurrentTreeNodeIndex++;

                    foreach (TreeNode ChildNode in CurrentTreeNode.Nodes)
                    {
                        CreateCopyQueue.Enqueue(ChildNode);
                    }
                }
            }

            TreeNodeIndex = CurrentTreeNodeIndex;
        }

        // Метод разбития словаря закладок на составные компоненты и дальнейшее их сохранение в файл
        public void ContentsBookmarkListDividerAndSaver()
        {
            ICollection<string> Keys = DictionariesKeeperClass.ContentsBookmarkDictionary.Keys;
            string[] Descriptions = DictionariesKeeperClass.ContentsBookmarkDictionary.Values.Select(x => x.Item1).ToArray();
            string[] Timestamps = DictionariesKeeperClass.ContentsBookmarkDictionary.Values.Select(x => x.Item2).ToArray();
            string[] Parents = DictionariesKeeperClass.ContentsBookmarkDictionary.Values.Select(x => x.Item3).ToArray();
            string[] Contents = DictionariesKeeperClass.ContentsBookmarkDictionary.Values.Select(x => x.Item4).ToArray();

            _CurrentData.ContentsBookmarkDictionaryKeys = new string[Keys.Count];
            _CurrentData.ContentsBookmarkDictionaryDescriptions = new string[Descriptions.Length];
            _CurrentData.ContentsBookmarkDictionaryTimestamps = new string[Timestamps.Length];
            _CurrentData.ContentsBookmarkDictionaryParents = new string[Parents.Length];
            _CurrentData.ContentsBookmarkDictionaryContents = new string[Contents.Length];

            int i = 0;
            int j = 0;
            int k = 0;
            int l = 0;
            int m = 0;

            foreach (string Key in Keys)
            {
                _CurrentData.ContentsBookmarkDictionaryKeys[i] = Key;
                i++;
            }

            foreach (string Description in Descriptions)
            {
                _CurrentData.ContentsBookmarkDictionaryDescriptions[j] = Description;
                j++;
            }

            foreach (string Timestamp in Timestamps)
            {
                _CurrentData.ContentsBookmarkDictionaryTimestamps[k] = Timestamp;
                k++;
            }

            foreach (string Parent in Parents)
            {
                _CurrentData.ContentsBookmarkDictionaryParents[l] = Parent;
                l++;
            }

            foreach (string Content in Contents)
            {
                _CurrentData.ContentsBookmarkDictionaryContents[m] = Content;
                m++;
            }
        }

        // Метод загрузки сохранённых данных
        public void LoadSavedData()
        {
            RecreateTreeView();
            RecreateTreeViewData();
        }

        // Метод загрузки TreeView
        public void RecreateTreeView()
        {
            int ParentTreeNodeIndex = -1; // индекс главной родительской ветви

            if (_CurrentData.TreeViewNodeKey != null && _CurrentData.TreeViewParentKey != null && _CurrentData.TreeViewNodeText != null)
            {
                foreach (int Key in _CurrentData.TreeViewNodeKey)
                {
                    if (_CurrentData.TreeViewParentKey[Key] == -1)
                    {
                        _ContentsBookmarkList.Nodes.Add(_CurrentData.TreeViewNodeText[Key]);
                        ParentTreeNodeIndex++;
                    }

                    else
                    {
                        RecreateEachChildNode(_ContentsBookmarkList, ParentTreeNodeIndex, Key);
                    }
                }
            }

            _ContentsBookmarkList.ExpandAll();
        }

        // Метод загрузки дочерних ветвей узла TreeView [?]
        public void RecreateEachChildNode(TreeView TreeView, int ParentTreeNodeIndex, int Key)
        {
            TreeNode ParentTreeNode = TreeView.Nodes[ParentTreeNodeIndex]; // главная родительская ветвь
            int ParentKey = _CurrentData.TreeViewParentKey[Key]; // индекс родителя текущей ветви
            int IndexOfCurrentNode = 0; // индекс текущей ветви

            Queue<TreeNode> RecreateQueue = new();
            RecreateQueue.Enqueue(ParentTreeNode);

            while (RecreateQueue.Count > 0)
            {
                ParentTreeNode = RecreateQueue.Dequeue();

                if (ParentKey != 0)
                {
                    foreach (TreeNode ChildNode in ParentTreeNode.Nodes)
                    {
                        IndexOfCurrentNode++;

                        if (IndexOfCurrentNode == ParentKey)
                        {
                            ParentTreeNode = ChildNode;
                            RecreateQueue.Clear();
                            break;
                        }

                        else
                        {
                            RecreateQueue.Enqueue(ChildNode);
                        }
                    }
                }
            }

            ParentTreeNode.Nodes.Add(_CurrentData.TreeViewNodeText[Key]);
        }

        // Метод загрузки содержимого TreeView
        public void RecreateTreeViewData()
        {
            int CurrentBookmarkIndex = 0;

            if (_CurrentData.ContentsBookmarkDictionaryKeys != null)
            {
                foreach (string Key in _CurrentData.ContentsBookmarkDictionaryKeys)
                {
                    DictionariesKeeperClass.ContentsBookmarkDictionary.Add(_CurrentData.ContentsBookmarkDictionaryKeys[CurrentBookmarkIndex], Tuple.Create(_CurrentData.ContentsBookmarkDictionaryDescriptions[CurrentBookmarkIndex], _CurrentData.ContentsBookmarkDictionaryTimestamps[CurrentBookmarkIndex], _CurrentData.ContentsBookmarkDictionaryParents[CurrentBookmarkIndex], _CurrentData.ContentsBookmarkDictionaryContents[CurrentBookmarkIndex]));
                    CurrentBookmarkIndex++;
                }
            }
        }
    }
}
