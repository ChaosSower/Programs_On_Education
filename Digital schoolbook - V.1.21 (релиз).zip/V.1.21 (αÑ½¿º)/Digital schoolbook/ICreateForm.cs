﻿using System.Windows.Forms;

namespace Digital_schoolbook
{
    // Интерфейс создания форм для главной формы
    public interface ICreateForm
    {
        void GetParameters(TreeView ContentsBookmarkList, RichTextBox BookmarkDescriptionRichTextBox, TextBox BookmarkTimeInfoTextBox, TextBox BookmarkChapterInfoTextBox, RichTextBox BookmarkContentRichTextBox, CheckBox CreatorModeCheckBox, Label MissingBookmarkMessageLabel, SplitContainer BookmarkContentEditorAndRemover); // функция передачи и приёма элементов с главной формы
        void CreateForm(ICreateForm CreateClass, MainWindow MainWindowForm); // функция создания класса
    }

    // Класс реализации интерфейса создания форм для главной формы - создание формы оформления закладок
    public class CreateBookmarkEditorFormClass : ICreateForm
    {
        public TreeView ContentsBookmarkList_ { get; set; }
        public RichTextBox BookmarkDescriptionRichTextBox_ { get; set; }
        public TextBox BookmarkTimeInfoTextBox_ { get; set; }
        public TextBox BookmarkChapterInfoTextBox_ { get; set; }
        public RichTextBox BookmarkContentRichTextBox_ { get; set; }
        public CheckBox CreatorModeCheckBox_ { get; set; }
        public Label MissingBookmarkMessageLabel_ { get; set; }
        public SplitContainer BookmarkContentEditorAndRemover_ { get; set; }

        public void GetParameters(TreeView ContentsBookmarkList, RichTextBox BookmarkDescriptionRichTextBox, TextBox BookmarkTimeInfoTextBox, TextBox BookmarkChapterInfoTextBox, RichTextBox BookmarkContentRichTextBox, CheckBox CreatorModeCheckBox, Label MissingBookmarkMessageLabel, SplitContainer BookmarkContentEditorAndRemover)
        {
            ContentsBookmarkList_ = ContentsBookmarkList;
            BookmarkDescriptionRichTextBox_ = BookmarkDescriptionRichTextBox;
            BookmarkTimeInfoTextBox_ = BookmarkTimeInfoTextBox;
            BookmarkChapterInfoTextBox_ = BookmarkChapterInfoTextBox;
            BookmarkContentRichTextBox_ = BookmarkContentRichTextBox;
            CreatorModeCheckBox_ = CreatorModeCheckBox;
            MissingBookmarkMessageLabel_ = MissingBookmarkMessageLabel;
            BookmarkContentEditorAndRemover_ = BookmarkContentEditorAndRemover;
        }

        private BookmarkEditor BookmarkEditorForm; // инициализация экземпляра формы оформления закладок

        // Инициализация делегатов //
        public delegate void FlipCreatorModeCheckBoxDelegate(); // инициализация делегата переключения режима создания закладок

        // Переменные делегатов //
        public FlipCreatorModeCheckBoxDelegate FlipCreatorModeCheckBoxDelegateVariable; // переменная делегата переключения режима создания закладок

        public void CreateForm(ICreateForm CreateForm, MainWindow MainWindowForm)
        {
            FlipCreatorModeCheckBoxDelegateVariable = MainWindowForm.ProjectMethods.FlipCreatorModeCheckBox; // передача переменной делегата метода возвращения состояния чек-бокса смены режима редактирования файла

            using (BookmarkEditorForm = new() // создание экземпляра формы оформления закладок
            {
                _ContentsBookmarkList = ContentsBookmarkList_, // передача ссылки на дерево закладок созданной форме
                _BookmarkDescriptionRichTextBox = BookmarkDescriptionRichTextBox_, // передача ссылки на текстовое поле описания закладки созданной форме
                _BookmarkTimeInfoTextBox = BookmarkTimeInfoTextBox_, // передача ссылки на текстовое поле времени создания / редактирования закладки созданной форме
                _BookmarkChapterInfoTextBox = BookmarkChapterInfoTextBox_, // передача ссылки на текстовое поле главы закладки созданной форме
                _BookmarkContentRichTextBox = BookmarkContentRichTextBox_, // передача ссылки на текстовое поле содержимого закладки созданной форме
                _CreatorModeCheckBox = CreatorModeCheckBox_, // передача ссылки на чек-бокс смены режима редактирования содержимого закладки созданной форме
                _MissingBookmarkMessageLabel = MissingBookmarkMessageLabel_, // передача ссылки на ярлык отсутствия закладок созданной форме
                _BookmarkContentEditorAndRemover = BookmarkContentEditorAndRemover_, // передача ссылки на контейнер редактора содержимого закладки созданной форме
                _FlipCreatorModeCheckBoxDelegateVariable = FlipCreatorModeCheckBoxDelegateVariable // передача ссылки на переменную делегата метода созданной форме
            })

            {
                BookmarkEditorForm.ShowDialog(); // открытие формы оформления закладок
            }
        }
    }

    // Класс реализации интерфейса создания форм для главной формы - создание формы оформления содержимого закладки
    public class CreateBookmarkContentEditorForm : ICreateForm
    {
        public TreeView ContentsBookmarkList_ { get; set; }
        public RichTextBox BookmarkDescriptionRichTextBox_ { get; set; }
        public TextBox BookmarkTimeInfoTextBox_ { get; set; }
        public TextBox BookmarkChapterInfoTextBox_ { get; set; }
        public RichTextBox BookmarkContentRichTextBox_ { get; set; }

        public void GetParameters(TreeView ContentsBookmarkList, RichTextBox BookmarkDescriptionRichTextBox, TextBox BookmarkTimeInfoTextBox, TextBox BookmarkChapterInfoTextBox, RichTextBox BookmarkContentRichTextBox, CheckBox CreatorModeCheckBox, Label MissingBookmarkMessageLabel, SplitContainer BookmarkContentEditorAndRemover)
        {
            ContentsBookmarkList_ = ContentsBookmarkList;
            BookmarkDescriptionRichTextBox_ = BookmarkDescriptionRichTextBox;
            BookmarkTimeInfoTextBox_ = BookmarkTimeInfoTextBox;
            BookmarkChapterInfoTextBox_ = BookmarkChapterInfoTextBox;
            BookmarkContentRichTextBox_ = BookmarkContentRichTextBox;
        }

        private BookmarkContentEditor BookmarkContentEditorForm; // инициализация экземпляра формы оформления содержимого закладки

        public void CreateForm(ICreateForm CreateForm, MainWindow MainWindowForm)
        {
            using (BookmarkContentEditorForm = new() // создание экземпляра формы оформления содержимого закладки
            {
                _ContentsBookmarkList = ContentsBookmarkList_,
                _BookmarkDescriptionRichTextBox = BookmarkDescriptionRichTextBox_,
                _BookmarkTimeInfoTextBox = BookmarkTimeInfoTextBox_,
                _BookmarkChapterInfoTextBox = BookmarkChapterInfoTextBox_,
                _BookmarkContentRichTextBox = BookmarkContentRichTextBox_
            })

            {
                BookmarkContentEditorForm.ShowDialog();
            }
        }
    }
}