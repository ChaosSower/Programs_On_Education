﻿namespace SavedDataFileName
{
    public class SavedDataFileNameClass
    {
        public static string SavedUserDataFileName = "SavedUserData.xml"; // название файла сохранения данных
    }
}