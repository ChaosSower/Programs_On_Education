﻿using System;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using CustomHelpProvider;
using DictionariesKeeper;

namespace Digital_schoolbook
{
    public partial class BookmarkEditor : Form
    {
        public BookmarkEditor()
        {
            InitializeComponent();

            BookmarkDescriptionRichTextBox.AllowDrop = true;

            // Подписки на события перетаскивания текста в описание закладки
            BookmarkDescriptionRichTextBox.DragEnter += new(BookmarkDescriptionRichTextBox_DragEnter);
            BookmarkDescriptionRichTextBox.DragDrop += new(BookmarkDescriptionRichTextBox_DragDrop);
        }

        // Инициализация экземпляров элементов //
        private Timer HelpPopUpTimer; // инициализация экземпляра таймера всплывающей подсказки

        // Инициализация экземпляров классов и форм //
        private BookmarkEditorMethodsClass BookmarkEditorMethods; // инициализация экземпляра класса методов формы оформления закладок

        // Получение ссылок //
        public TreeView _ContentsBookmarkList; // получение ссылки на дерево закладок
        public RichTextBox _BookmarkDescriptionRichTextBox; // получение ссылки на текстовое поле главной формы описания закладки
        public TextBox _BookmarkTimeInfoTextBox; // получение ссылки на текстовое поле главной формы данных о создании / редактировании закладки
        public TextBox _BookmarkChapterInfoTextBox; // получение ссылки на текстовое поле главной формы данных о главе закладки
        public RichTextBox _BookmarkContentRichTextBox; // получение ссылки на текстовое поле главной формы содержания закладки
        public CheckBox _CreatorModeCheckBox; // получение ссылки на чек-бокс смены режима редактирования содержимого закладки главной формы
        public Label _MissingBookmarkMessageLabel; // получение ссылки на ярлык отсутствия закладок главной формы
        public SplitContainer _BookmarkContentEditorAndRemover; // получение ссылки на контейнер редактора содержимого закладки главной формы
        public CreateBookmarkEditorFormClass.FlipCreatorModeCheckBoxDelegate _FlipCreatorModeCheckBoxDelegateVariable; // получение ссылки на переменную делегата с функцией из класса формы оформления закладок, реализующего интерфейс

        // Создание событий //
        private event EventHandler AbortButton_Clicked; // создание события проверки нажатия кнопки отмены
        private event EventHandler ConfirmButton_Clicked; // создание события проверки нажатия кнопки подтверждения

        // События //

        // Событие нажатия кнопки отмены добавления закладки
        private void AddBookmarkAbortButton_Click(object sender, EventArgs e)
        {
            AbortButton_Clicked += AddBookmarkAbortButton_Click;

            if (!EditingExistingBookmark)
            {
                _ContentsBookmarkList.SelectedNode.Remove();
            }

            _ContentsBookmarkList.SelectedNode = null; // снятие выделения с добавленной закладки

            Close();
            Dispose(true);
        }

        private string BookmarkName; // название закладки

        // Событие нажатия кнопки подтверждения добавления закладки
        private void AddBookmarkConfirmButton_Click(object sender, EventArgs e)
        {
            BookmarkName = BookmarkNameTextBox.Text;

            if (BookmarkName == "")
            {
                MessageBox.Show("Вы не ввели название закладки! Пожалуйста, введите название закладки");
                return;
            }

            string BookmarkDescription = BookmarkDescriptionRichTextBox.Text;

            if (BookmarkDescription == "")
            {
                BookmarkDescription = null;
            }

            string BookmarkTimestamp = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
            string BookmarkParent;

            if (_ContentsBookmarkList.SelectedNode.Parent != null)
            {
                BookmarkParent = _ContentsBookmarkList.SelectedNode.Parent.Text;
            }

            else
            {
                BookmarkParent = null;
            }

            string BookmarkContent;

            if (EditingExistingBookmark)
            {
                BookmarkContent = DictionariesKeeperClass.ContentsBookmarkDictionary[_ContentsBookmarkList.SelectedNode.Text].Item4;

                if (BookmarkName == _ContentsBookmarkList.SelectedNode.Text && BookmarkDescription == DictionariesKeeperClass.ContentsBookmarkDictionary[_ContentsBookmarkList.SelectedNode.Text].Item1)
                {
                    MessageBox.Show("Название и описание закладки не были изменены! Пожалуйста, измените название или описание закладки");
                    return;
                }

                DictionariesKeeperClass.ContentsBookmarkDictionary.Remove(_ContentsBookmarkList.SelectedNode.Text); // удаление устаревшей закладки
                DictionariesKeeperClass.ContentsBookmarkDictionary.Add(BookmarkName, Tuple.Create(BookmarkDescription, BookmarkTimestamp, BookmarkParent, BookmarkContent)); // добавление ("замена") закладки в словарь
            }

            else
            {
                BookmarkContent = null;

                try
                {
                    DictionariesKeeperClass.ContentsBookmarkDictionary.Add(BookmarkName, Tuple.Create(BookmarkDescription, BookmarkTimestamp, BookmarkParent, BookmarkContent)); // добавление закладки в словарь
                }

                catch (ArgumentException)
                {
                    MessageBox.Show("Закладка с таким названием уже существует! Пожалуйста, введите другое название закладки");
                    return;
                }

                BookmarkEditorMethods = new() // создание экземпляра класса методов формы оформления закладок
                {
                    _BookmarkName = BookmarkName // передача ссылки на название закладки экземпляру класса
                };

                BookmarkEditorMethods.CreateBookmarkFolderCopy(_ContentsBookmarkList.SelectedNode);
            }

            ConfirmButton_Clicked += AddBookmarkConfirmButton_Click;

            _ContentsBookmarkList.SelectedNode.Text = BookmarkName;
            _ContentsBookmarkList.SelectedNode = null;

            Close();
            Dispose(true);
        }

        // Событие перетаскивания текста на текстовое поле названия закладки [?!V Google текст из поиска некорректно вставляется]
        private void BookmarkNameTextBox_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Text))
            {
                e.Effect = DragDropEffects.Copy;
            }

            else
            {
                e.Effect = DragDropEffects.None;
            }
        }

        private int CursorPosition; // позиция курсора в текстовом поле
        private string PreviousText; // текст до перетаскивания

        // Событие вставки перетаскиваемого текста на текстовое поле названия закладки [?]
        private void BookmarkNameTextBox_DragDrop(object sender, DragEventArgs e)
        {
            CursorPosition = BookmarkNameTextBox.SelectionStart;
            PreviousText = BookmarkNameTextBox.Text.Substring(CursorPosition);
            BookmarkNameTextBox.Text = BookmarkNameTextBox.Text.Substring(0, CursorPosition); // сохранения текста

            BookmarkNameTextBox.Text += e.Data.GetData(DataFormats.Text).ToString(); // добавление перенесённого текста
            BookmarkNameTextBox.Text += PreviousText;
        }

        // Событие перетаскивания текста на текстовое поле описания закладки [?!V Сделать с фото]
        private void BookmarkDescriptionRichTextBox_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Text) || e.Data.GetDataPresent(DataFormats.Bitmap))
            {
                e.Effect = DragDropEffects.Copy;
            }

            else
            {
                e.Effect = DragDropEffects.None;
            }
        }

        // Событие вставки перетаскиваемого текста на текстовое поле описания закладки [?]
        private void BookmarkDescriptionRichTextBox_DragDrop(object sender, DragEventArgs e)
        {
            CursorPosition = BookmarkDescriptionRichTextBox.SelectionStart;
            PreviousText = BookmarkDescriptionRichTextBox.Text.Substring(CursorPosition);
            BookmarkDescriptionRichTextBox.Text = BookmarkDescriptionRichTextBox.Text.Substring(0, CursorPosition);

            BookmarkDescriptionRichTextBox.Text += e.Data.GetData(DataFormats.Text).ToString();
            BookmarkDescriptionRichTextBox.Text += PreviousText;
        }

        // Событие изменения текста названия закладки [?]
        private async void BookmarkNameTextBox_TextChanged(object sender, EventArgs e)
        {
            await Task.Run(() =>
            {
                BookmarkNameTextBox.Invoke((MethodInvoker)delegate
                {
                    if (Regex.IsMatch(BookmarkNameTextBox.Text, @"[\\,/,:,*,?,"",<,>,|]"))
                    {
                        BookmarkNameTextBox.Text = BookmarkNameTextBox.Text.Remove(BookmarkNameTextBox.Text.Length - 1);
                        BookmarkNameTextBox.SelectionStart = BookmarkNameTextBox.TextLength;

                        HelpExtensions.ShowPopup(BookmarkNameTextBox, "Название закладки не может содержать следующие символы: \\ / : * ? \"\" < > |", new(Location.X + 95, Location.Y + 70 + BookmarkNameTextBox.Height));

                        if (HelpPopUpTimer != null)
                        {
                            HelpPopUpTimer.Stop();
                            HelpPopUpTimer.Dispose();
                            HelpPopUpTimerTicks = 0;
                        }

                        HelpPopUpTimer = new()
                        {
                            Interval = 1000
                        };

                        HelpPopUpTimer.Start();
                        HelpPopUpTimer.Tick += PopUpTimer_Tick;
                    }

                    else
                    {
                        BookmarkName = BookmarkNameTextBox.Text;
                    }
                });
            });
        }

        private int HelpPopUpTimerTicks; // переменная количества тиков таймера всплывающей подсказки

        // Событие тика таймера всплывающей подсказки
        private void PopUpTimer_Tick(object sender, EventArgs e)
        {
            HelpPopUpTimerTicks++;

            if (HelpPopUpTimerTicks == 10)
            {
                BookmarkNameTextBox.Focus();
                HelpPopUpTimer.Stop();
                HelpPopUpTimer.Dispose();
                HelpPopUpTimerTicks = 0;
            }
        }

        // Событие изменения текста описания закладки [?]
        private async void BookmarkDescriptionRichTextBox_TextChanged(object sender, EventArgs e)
        {
            await Task.Run(() =>
            {
                BookmarkDescriptionRichTextBox.Invoke((MethodInvoker)delegate
                {
                    if (BookmarkDescriptionRichTextBox.Lines.Length > 10 || BookmarkDescriptionRichTextBox.TextLength > 770 || (BookmarkDescriptionRichTextBox.Lines.Length >= 0 && BookmarkDescriptionRichTextBox.TextLength > 55))
                    {
                        BookmarkDescriptionRichTextBox.ScrollBars = RichTextBoxScrollBars.Vertical;
                    }

                    else
                    {
                        BookmarkDescriptionRichTextBox.ScrollBars = RichTextBoxScrollBars.None;
                    }
                });
            });
        }

        private bool EditingExistingBookmark = false; // переменная сигнала на редактирование существующей закладки

        // Событие проверки данных перед открытием формы
        private void BookmarkEditor_Load(object sender, EventArgs e)
        {
            if (MainWindow.EditBookmarkContextMenu_Clicked || MainWindow.EditBookmarkDescriptionContextMenu_Clicked)
            {
                Text = "Редактирование закладки";
                AddBookmarkConfirmButton.Text = "Сохранить изменения";

                EditingExistingBookmark = true; // подача сигнала на редактирование существующей закладки

                BookmarkNameTextBox.Text = _ContentsBookmarkList.SelectedNode.Text;
                BookmarkDescriptionRichTextBox.Text = DictionariesKeeperClass.ContentsBookmarkDictionary[_ContentsBookmarkList.SelectedNode.Text].Item1;

                if (MainWindow.EditBookmarkContextMenu_Clicked)
                {
                    BookmarkNameTextBox.Select();
                }

                else
                {
                    BookmarkDescriptionRichTextBox.Select();
                    BookmarkDescriptionRichTextBox.SelectAll();
                }
            }
        }

        // Событие проверки данных перед закрытием формы
        private void BookmarkEditor_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (AbortButton_Clicked != null)
            {
                e.Cancel = false;
            }

            else if (BookmarkName == null || BookmarkName == "")
            {
                MessageBox.Show("Вы не ввели название закладки! Пожалуйста, введите название закладки");
                e.Cancel = true;
            }

            else if (ConfirmButton_Clicked == null)
            {
                MessageBox.Show("Вы не подтвердили название закладки! Пожалуйста, подтвердите название закладки");
                e.Cancel = true;
            }

            AbortButton_Clicked -= AddBookmarkAbortButton_Click;
            ConfirmButton_Clicked -= AddBookmarkConfirmButton_Click;
        }

        // Событие очистки данных главной формы после закрытия формы
        private void BookmarkEditor_FormClosed(object sender, FormClosedEventArgs e)
        {
            _BookmarkDescriptionRichTextBox.Text = null;
            _BookmarkTimeInfoTextBox.Text = null;
            _BookmarkChapterInfoTextBox.Text = null;
            _BookmarkContentRichTextBox.Text = null;

            if (_ContentsBookmarkList.Nodes.Count == 1 && !EditingExistingBookmark)
            {
                _BookmarkContentRichTextBox.Show();
                _BookmarkContentEditorAndRemover.Show();
                _MissingBookmarkMessageLabel.Hide();

                if (!_CreatorModeCheckBox.Checked)
                {
                    _FlipCreatorModeCheckBoxDelegateVariable.Invoke();
                }
            }
        }
    }
}