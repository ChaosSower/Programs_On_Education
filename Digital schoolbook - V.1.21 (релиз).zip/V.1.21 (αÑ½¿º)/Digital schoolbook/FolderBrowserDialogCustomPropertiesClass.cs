﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace Digital_schoolbook
{
    // Клас свойства изменения размера окна FolderBrowserDialog
    class FolderBrowserDialogSize : IDisposable
    {
        private int mTries = 0;
        private readonly Form FormOwner;

        public FolderBrowserDialogSize(Form CurrentFormOwner)
        {
            FormOwner = CurrentFormOwner;
            CurrentFormOwner.BeginInvoke(new Action(FindFolderBrowserDialog));
        }

        public Size DialogSize { get; set; }

        // Метод поиска FolderBrowserDialog
        private void FindFolderBrowserDialog()
        {
            // Enumerate windows to find the message box
            if (mTries < 0)
            {
                return;
            }

            EnumThreadWndProc CallBack = new(CheckWindow);

            if (EnumThreadWindows(GetCurrentThreadId(), CallBack, IntPtr.Zero))
            {
                if (++mTries < 10)
                {
                    FormOwner.BeginInvoke(new MethodInvoker(FindFolderBrowserDialog));
                }
            }
        }

        // Метод проверки окна
        private bool CheckWindow(IntPtr hWnd, IntPtr lp)
        {
            // Checks if <hWnd> is a dialog
            StringBuilder CurrentStringBuilder = new(260);

            GetClassName(hWnd, CurrentStringBuilder, CurrentStringBuilder.Capacity);

            if (CurrentStringBuilder.ToString() != "#32770")
            {
                return true;
            }

            GetWindowRect(hWnd, out RECT dlgRect);
            SetWindowPos(new(this, hWnd), new(), dlgRect.Left, dlgRect.Top, DialogSize.Width, DialogSize.Height, 20 | 2);

            return false;
        }

        // Метод высвобождения ресурсов
        public void Dispose()
        {
            mTries = -1;
        }

        // P/Invoke declarations
        private delegate bool EnumThreadWndProc(IntPtr hWnd, IntPtr lp);
        [DllImport("user32.dll")]
        private static extern bool EnumThreadWindows(int tid, EnumThreadWndProc callback, IntPtr lp);
        [DllImport("kernel32.dll")]
        private static extern int GetCurrentThreadId();
        [DllImport("user32.dll")]
        private static extern int GetClassName(IntPtr hWnd, StringBuilder buffer, int buflen);
        [DllImport("user32.dll")]
        private static extern bool GetWindowRect(IntPtr hWnd, out RECT rc);
        [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
        public static extern bool SetWindowPos(HandleRef hWnd, HandleRef hWndInsertAfter, int x, int y, int cx, int cy, int flags);

        private struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
    }
}