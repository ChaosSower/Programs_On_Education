﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace Digital_schoolbook
{
    public class BookmarkEditorMethodsClass
    {
        // Получение ссылок //
        public string _BookmarkName; // получение ссылки на название закладки

        // Методы //

        // Метод создания копии словаря закладок [!]
        public void CreateBookmarkFolderCopy(TreeNode CurrentTreeNode)
        {
            string BookmarkFolderName = _BookmarkName; // название папки-закладки
            string BookmarkFolderPath = Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory + @"\..\..\[Содержимое электронного учебника]"); // путь папки закладок

            if (!Directory.Exists(BookmarkFolderPath)) // проверка наличия папки с закладками
            {
                Directory.CreateDirectory(Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory + @"\..\..\[Содержимое электронного учебника]")); // создание папки c закладками
            }

            if (CurrentTreeNode.Parent == null)
            {
                string FullBookmarkFolderPath = Path.Combine(Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory + @"\..\..\[Содержимое электронного учебника]"), BookmarkFolderName); // путь папки-закладки
                Directory.CreateDirectory(FullBookmarkFolderPath); // создание папки-закладки
            }

            else
            {
                CreateFolderCopyOfChildNode(CurrentTreeNode, _BookmarkName);
            }
        }

        // Метод создания копии закладок дочерних ветвей узла путём перебора [?!]
        public void CreateFolderCopyOfChildNode(TreeNode CurrentTreeNode, string BookmarkFolderName)
        {
            List<string> UsedPaths = new(); // список использованных путей
            string BookmarkFolderPath = Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory + @"\..\..\[Содержимое электронного учебника]");
            string FullBookmarkFolderPath;

            Queue<TreeNode> CreateFolderQueue = new();
            CreateFolderQueue.Enqueue(CurrentTreeNode);

            while (CreateFolderQueue.Count > 0)
            {
                CurrentTreeNode = CreateFolderQueue.Peek();

                while (CurrentTreeNode.Parent != null)
                {
                    if (!UsedPaths.Contains(CurrentTreeNode.Parent.Text))
                    {
                        CurrentTreeNode = CurrentTreeNode.Parent;
                    }

                    else
                    {
                        break;
                    }
                }

                if (!UsedPaths.Contains(CurrentTreeNode.Text))
                {
                    BookmarkFolderPath += @"\" + CurrentTreeNode.Text;
                    UsedPaths.Add(CurrentTreeNode.Text); // добавление пути в стоп-лист
                }

                CurrentTreeNode = CreateFolderQueue.Peek();
                CreateFolderQueue.Dequeue();

                if (!UsedPaths.Contains(CurrentTreeNode.Parent.Text))
                {
                    CreateFolderQueue.Enqueue(CurrentTreeNode);
                }
            }

            FullBookmarkFolderPath = Path.Combine(BookmarkFolderPath, BookmarkFolderName);
            Directory.CreateDirectory(FullBookmarkFolderPath);
        }
    }
}